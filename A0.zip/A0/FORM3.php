<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <title>resultat</title>
    <style>
        body {
            border: 2px solid black;
            border-radius: 5px;
            width: 800px;
            margin: 30px;
            text-align: center;
            
        }

        form {


            justify-content: center;
            align-items: center;
            box-shadow: 0px 4px 8px rgba(0, 0, 0, 0.1); /* Optional: adds shadow for effect */
            border: 2px solid black;
            height: 200px;
            padding: 40px;
        }
        p{
            margin:30px;
            font-size:30px;
        }
        footer{
            text-align: center;
            margin: 20px;
            font-weight: bold;
            font-size: 20px;
        }

        

    </style>
</head>
<body>
    <header>
        <img src="img/logo.png" alt="logo fssm">
    </header>
    <form>
    <?php
       $name= $_GET["identifiant"];
       $math= $_GET["maths"];
       $info= $_GET["informatique"];
       $somme=$math+$info;
       $moyenn= $somme/2;
       $formattedMoyenn = number_format($moyenn, 2, '.', '');
       if ($moyenn>=12 && $moyenn<14)
       $namemontion=" assez bien";
    else if ($moyenn>=14&& $moyenn<16)
    $namemontion="  bien";
    else if ($moyenn>=16 )
       $namemontion=" tres bien";
    else
    $namemontion=" Malheureusement , votre admission n'a pas été retenue"; 
    echo "<p><strong>Bienvenue $name</strong></p>";
    echo"<p ><span style='background-color: #c9e5f2;'> Votre résultat est $formattedMoyenn</span> </p>";

    echo "<p style='color:red;'> $namemontion </p>";
    ?> 
    </form>
    <footer>
        contacternous@gmail.com
    </footer>
</body>
</html>