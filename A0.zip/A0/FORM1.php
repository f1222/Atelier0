<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel='stylesheet' type='text/css' media='screen' href='css/style1.css'>
    <title>CONNEXION</title>

</head>
<body>
        <header>
            <img src="img/logo.png" alt="logo fssm">
        </header>
        <form action="form1.php" method="get">
            <?php
                $Id = isset($_GET["identifiant"]) ? $_GET["identifiant"] : "";
                $Mp = isset($_GET["motdepasse"]) ? $_GET["motdepasse"] : "";
                $ConsId = "FSSM";
                $ConsMP = "smi";
                $resultat1 = strcmp($ConsId, $Id);
                $resultat2 = strcmp($ConsMP, $Mp);
            ?>
            <label class="label1" for="identifiant">Identifiant</label>
            <input class="input1"  type="text" name="identifiant"><br>
            <label class="label2" for="mdp">Mot de Passe</label>
            <input class="input2" type="password"  name="motdepasse">

            <div class="button1">
                <button type="submit">Valider
                    <?php
                        if ($resultat1 == 0 && $resultat2 == 0) {
                            header("location:FORM2.php");
                        } 
                        else{
                            echo "Identifiant ou Mot de passe Incorrect ...  !!"; 
                        }
                    ?>
                </button>
            </div>
        </form>
        <footer>
            contacternous@gmail.com
        </footer>
</body>
</html>