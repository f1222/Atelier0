<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel='stylesheet' type='text/css' media='screen' href='css/style2.css'>
    <title>CALCUL</title>

</head>
<body>
        <header>
            <img src="img/logo.png" alt="logo fssm">
        </header>
        <form action="form3.php" method="get">
            <div class="container">
                <label class="lab1" for="etudiant">Etudiant</label>
                <input class="inpt1" type="text" name="identifiant"><br>
                <label class="lab2" for="maths">Maths</label>
                <input class="inpt2" type="text" name="maths" ><br>
                <label class="lab3"  for="informatique">Informatique</label>
                <input class="inpt3" type="text"  name="informatique">
            </div>
            <div class="but">
                <button type="submit">Résultats</button>
                <button type="reset">Annuler</button>
            </div>

        </form>
        <footer>
            contacternous@gmail.com
        </footer>
</body>
</html>
